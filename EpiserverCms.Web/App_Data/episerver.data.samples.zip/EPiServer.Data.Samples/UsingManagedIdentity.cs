﻿using System;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class UsingManagedIdentity : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            //....obtain a Guid from an external source for the new item
            Guid newId = Guid.NewGuid();

            // Save a new person
            PersonWithIDynamicData p = new PersonWithIDynamicData()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25),
                Gender = 'm',
                Id = Identity.NewIdentity(newId)
            };

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(PersonWithIDynamicData));
            Identity id = store.Save(p);

            // The ExternalId of the Identity returned by the Save method should be the same value as the Id property
            host.Assert(p.Id.ExternalId.Equals(id.ExternalId));

            // Now load the person back
            PersonWithIDynamicData loadedPerson = store.Load<PersonWithIDynamicData>(id);

            // Ensure we got out person back
            host.Assert(loadedPerson != null);

            host.Out.WriteLine(loadedPerson.FirstName);
            host.Out.WriteLine(loadedPerson.LastName);
            host.Out.WriteLine(loadedPerson.DateOfBirth);
            host.Out.WriteLine(loadedPerson.Gender);
            host.Out.WriteLine(loadedPerson.Id);
            host.WaitForUser();
        }
    }
}
