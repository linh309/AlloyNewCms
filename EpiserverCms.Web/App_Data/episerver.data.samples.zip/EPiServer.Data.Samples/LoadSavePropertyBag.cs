﻿using System;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class LoadSaveProperyBag : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Save a new person
            PropertyBag pb = new PropertyBag();
            pb.Add("FirstName", "Jack");
            pb.Add("LastName", "Williams");
            pb.Add("DateOfBirth", new DateTime(1973, 05, 25));
            pb.Add("Gender", 'm');

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", pb.GenerateTypeBag());
            Identity id = store.Save(pb);

            // Now load the person back
            PropertyBag pb2 = store.LoadAsPropertyBag(id);

            // Ensure we got out person back
            host.Assert(pb2 != null);

            host.Out.WriteLine(pb2["FirstName"]);
            host.Out.WriteLine(pb2["LastName"]);
            host.Out.WriteLine(pb2["DateOfBirth"]);
            host.Out.WriteLine(pb2["Gender"]);

            // you can load the properties back into a Type even though a PropertyBag was saved
            // only properties with matching names will be assigned to the object
            Person person = store.Load<Person>(id);
            host.Out.WriteLine(person.FirstName);
            host.Out.WriteLine(person.LastName);
            host.Out.WriteLine(person.DateOfBirth);

            // or load it as the type is was saved as (which is PropertyBag)
            object obj = store.Load(id);
            host.Assert(obj is PropertyBag);

            host.WaitForUser();
        }      
    }
}
