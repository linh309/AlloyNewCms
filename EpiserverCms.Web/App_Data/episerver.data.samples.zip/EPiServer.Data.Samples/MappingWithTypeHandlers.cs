﻿using System;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;
using EPiServer.Data.Samples.Host;

namespace EPiServer.Data.Samples
{
    class UriTypeHandler : ITypeHandler
    {
        IHostApplication _host;

        public UriTypeHandler(IHostApplication host)
        {
            _host = host;
        }

        #region ITypeHandler Members

        public Type MapToDatabaseType(Type type)
        {
            _host.Assert(type == typeof(Uri));

            // I know how to map a Uri to a String
            return typeof(String);
        }

        public object ToDatabaseFormat(string propertyName, object propertyValue, Type ownerType)
        {
            _host.Assert(propertyValue.GetType() == typeof(Uri));
            _host.Out.WriteLine(string.Format("Converting property '{0}' of Type {1} from Uri to String", propertyName, ownerType.FullName));

            // Uri.ToString() outputs a string representation of the Uri which can be saved in the Dynamic Data Store
            return propertyValue.ToString();
        }

        public object FromDatabaseFormat(string propertyName, object propertyValue, Type targetType, Type ownerType)
        {
            _host.Assert(targetType == typeof(Uri));
            _host.Out.WriteLine(string.Format("Converting property '{0}' of Type {1} from String to Uri", propertyName, ownerType.FullName));

            // Uri constructor takes a string
            return new Uri(propertyValue.ToString());
        }

        #endregion
    }

    class MappingWithTypeHandler : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Save a new person
            PersonWithTypeHandler p = new PersonWithTypeHandler()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25),
                Gender = 'm',
                WebSite = new Uri("http://www.MyHost/MyPage")
            };

            // Register a handler for Uri as it has no properties
            // that can be used by the DynamicDataStore to save and load it
            GlobalTypeHandlers.Instance.Add(typeof(Uri), new UriTypeHandler(host));

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(PersonWithTypeHandler));

            Identity id = store.Save(p);

            // Now load the person back
            PersonWithTypeHandler loadedPerson = store.Load<PersonWithTypeHandler>(id);

            // Ensure we got out person back
            host.Assert(loadedPerson != null);

            GlobalTypeHandlers.Instance.Remove(typeof(Uri));

            host.Out.WriteLine(loadedPerson.FirstName);
            host.Out.WriteLine(loadedPerson.LastName);
            host.Out.WriteLine(loadedPerson.DateOfBirth);
            host.Out.WriteLine(loadedPerson.Gender);
            host.Out.WriteLine(loadedPerson.WebSite);
            host.WaitForUser();
        }
    }
}

