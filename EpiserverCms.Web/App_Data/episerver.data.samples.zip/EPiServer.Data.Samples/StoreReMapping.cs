﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples
{
    class StoreReMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Note that the following example show how to do re-mapping using
            // totally dynamic types, i.e. type bags (string to Type dictionary)

            // to remap a .NET class to a store, the same API applies,
            // just pass in the Type to the Remap method of StoreDefinition

            // You can also use the EPiServerDataStoreAttribute on your .NET 
            // class and set the AutomaticallyRemapStore property to true.

            // Construct a typebag in order to map a store
            Dictionary<string, Type> typeBag = new Dictionary<string, Type>();
            typeBag.Add("A", typeof(String));
            typeBag.Add("B", typeof(long));
            typeBag.Add("C", typeof(DateTime));
            typeBag.Add("D", typeof(float));

            // Create a store based on this 'type'
            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("MyStore", typeBag);
            host.Assert(store != null);

            // if we drop down one level in the DDS stack and use the TypeMapper class
            // directly we can examine the mappings generated for the store
            StoreDefinition storeDef = StoreDefinition.Get("MyStore");
            IList<PropertyMap> mappings = storeDef.ActiveMappings.ToArray();

            // Assert some information about the mappings
            host.Assert(mappings.Count() == 4);

            // note that the mappings are in alphabetical order based on there name
            host.Assert(mappings[0].PropertyName == "A");
            host.Assert(mappings[1].PropertyName == "B");
            host.Assert(mappings[2].PropertyName == "C");
            host.Assert(mappings[3].PropertyName == "D");

            host.Assert(mappings[0].PropertyType == typeof(String));
            host.Assert(mappings[1].PropertyType == typeof(long));
            host.Assert(mappings[2].PropertyType == typeof(DateTime));
            host.Assert(mappings[3].PropertyType == typeof(float));

            // Now update the typeBag by adding a new property
            // This is exactly the same as changing a compiled type and using the DynamicDataStore<T> variant instead
            typeBag.Add("E", typeof(Guid));

            // and remap the store using the StoreDefinition class
            storeDef.Remap(typeBag);
            storeDef.CommitChanges();

            // re-get the mappings
            mappings = storeDef.ActiveMappings.ToArray();

            // should be 5 now
            host.Assert(mappings.Count() == 5);
            host.Assert(mappings[4].PropertyName == "E");
            host.Assert(mappings[4].PropertyType == typeof(Guid));

            // Rename a mapping
            storeDef.RenameProperty("E", "F");
            storeDef.CommitChanges();

            // re-get the mappings
            mappings = storeDef.ActiveMappings.ToArray();
            host.Assert(mappings[4].PropertyName == "F");

            // now lets change the type of some of the properties

            // downcase B from long to int - will it work?
            typeBag["B"] = typeof(int);
            storeDef.Remap(typeBag);
            storeDef.CommitChanges();

            // should do, no objects saved in the store yet

            // re-get the mappings
            mappings = storeDef.ActiveMappings.ToArray();
            host.Assert(mappings[1].PropertyType == typeof(int));

            // Now save a object in the store
            PropertyBag props = new PropertyBag();
            props.Add("B", int.MaxValue);
            store.Save(props);

            // downcase B from int to short - will it work?
            typeBag["B"] = typeof(short);

            try
            {
                storeDef.Remap(typeBag);
                storeDef.CommitChanges();
                host.Assert(false, "Exception should be thrown");
            }
            catch (InvalidOperationException exception)
            {
                // No, the int value we saved would cause an overflow when case to a short
                host.Out.WriteLine(exception.ToString());
            }


            host.WaitForUser();
        }
    }
}
