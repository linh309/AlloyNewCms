﻿using System;
using System.Linq;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class UsingImplicitIdentity : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Save a new person
            Person p = new Person()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25)
            };

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person));
            Identity id = store.Save(p);

            // Note that we get an Identity back which we can serialize along with our POCO object if we want.
            // To ASP.NET ViewState for example.

            // Update the object and save it back
            p.LastName = "Adams";
            Identity id2 = store.Save(p);

            // We should get the same Identity back as we have saved the object through the
            // same instance of the DynamicDataStore
            host.Assert(id == id2);

            // Load the object back to ensure it updated the name 
            Person loadedPerson = (from person in store.Items<Person>() where person.LastName == "Adams" select person).FirstOrDefault();

            // Ensure we got our object
            host.Assert(loadedPerson != null);

            // Update the item again
            loadedPerson.FirstName = "Jeff";

            // But save through another instance of the DynamicDataStore
            DynamicDataStore store2 = DynamicDataStoreFactory.Instance.GetStore("People");
            store2.Save(loadedPerson);

            // And now enumerate all objects in the store
            // and note that we have 2 instances of the object
            // as the state info was not found in store2
            foreach (Person person in store2.Items<Person>())
            {
                host.Out.WriteLine(person.FirstName);
                host.Out.WriteLine(person.LastName);
                host.Out.WriteLine(person.DateOfBirth);
            }

            host.WaitForUser();
        }       
    }
}
