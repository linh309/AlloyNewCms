﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Samples.Host;
using EPiServer.Data.Dynamic;
using System.Data.Common;
using EPiServer.Data.Dynamic.Providers;
using System.Data;

namespace EPiServer.Data.Samples
{
    public abstract class SampleBase
    {
        public abstract void Run(IHostApplication host);

        public void RunWithReset(IHostApplication host)
        {
            ResetDatabase();
            Run(host);
        }

        protected static void ResetDatabase()
        {
            DataStoreProvider provider = DataStoreProvider.CreateInstance();

            if (!(provider is DbDataStoreProvider))
            {
                throw new NotSupportedException("The samples required a database provider");
            }

            ((DbDataStoreProvider)provider).ExecuteTransaction(() =>
            {
                using (IDbCommand cmd = ((DbDataStoreProvider)provider).CreateCommand())
                {
                    cmd.CommandText = "delete from tblBigTableReference";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "delete from tblBigTable";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "delete from tblSystemBigTable";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "delete from tblBigTableIdentity";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "delete from tblBigTableStoreInfo";
                    cmd.ExecuteNonQuery();
                }
            });

            StoreDefinition.ClearCache();
        }
    }
}
