﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class UsingLinq : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            GlobalTypeToStoreMap.Instance.Add(typeof(Address), "Address");
            GlobalTypeToStoreMap.Instance.Add(typeof(Company), "Company");

            DynamicDataStore personStore = DynamicDataStoreFactory.Instance.CreateStore("Person", typeof(Person));

            // need to save some data to the store for the linq queries to be insteresting
            foreach (Person p in EPiServer.Data.Samples.Entities.Data.CreateData())
            {
                personStore.Save(p);
            }

            try
            {

                // SIMPLE QUERY TYPED
                host.Out.WriteLine("SIMPLE TYPED QUERY");
                var simpleTypedQuery = from person in personStore.Items<Person>()
                                       where person.LastName.EndsWith("sson")
                                  select person;

                foreach (var person in simpleTypedQuery)
                {
                    host.Out.WriteLine("{0} {1}", person.FirstName, person.LastName);
                }

                // SIMPLE QUERY PROPBAG
                host.Out.WriteLine("SIMPLE PROPBAG QUERY");
                var simpleUnTypedQuery = from propBag in personStore.ItemsAsPropertyBag()
                                         where ((string)propBag["LastName"]).EndsWith("sson")
                                         select propBag;

                foreach (var propBag in simpleUnTypedQuery)
                {
                    host.Out.WriteLine("{0} {1}", propBag["FirstName"], propBag["LastName"]);
                }

                // SELECTING SINGLE OBJECTS
                host.Out.WriteLine("SELECTING SINGLE OBJECTS");

                // Return the 1st object matching the query or null if none match
                var firstMatchingInstanceOrNull = (from person in personStore.Items<Person>()
                                               where person.LastName.EndsWith("sson")
                                               select person).FirstOrDefault();

                host.Out.WriteLine("{0} {1}", firstMatchingInstanceOrNull.FirstName, firstMatchingInstanceOrNull.LastName);

                // Return the 1st object matching the query or throw exception if none match
                var firstInstance = (from person in personStore.Items<Person>() select person).First();
                host.Out.WriteLine("{0} {1}", firstInstance.FirstName, firstInstance.LastName);

                // Return the single object matching the query, null if none match or throw an exception if more than one match
                var singleInstanceOrNull = (from person in personStore.Items<Person>()
                                            where person.LastName.EndsWith("yz")
                                      select person).SingleOrDefault();

                host.Out.WriteLine("{0} {1}", singleInstanceOrNull.FirstName, singleInstanceOrNull.LastName);

                // Return the single object matching the query or throws an exception if more than one match
                var singleInstance = (from person in personStore.Items<Person>()
                                      where person.LastName.EndsWith("yz")
                                      select person).Single();

                host.Out.WriteLine("{0} {1}", singleInstance.FirstName, singleInstance.LastName);

                // Return the last object matching the query or null if none match
                var lastMatchingInstanceOrNull = (from person in personStore.Items<Person>()
                                                   where person.LastName.EndsWith("sson")
                                                   select person).LastOrDefault();

                host.Out.WriteLine("{0} {1}", lastMatchingInstanceOrNull.FirstName, lastMatchingInstanceOrNull.LastName);

                // Return the last object matching the query or throw exception if none match
                var lastInstance = (from person in personStore.Items<Person>() select person).Last();

                host.Out.WriteLine("{0} {1}", lastInstance.FirstName, lastInstance.LastName);

                // SELECT NEW
                host.Out.WriteLine("SELECT NEW");
                var newQuery = from person in personStore.Items<Person>()
                               where person.LastName.EndsWith("sson")
                               select new
                               {
                                   FirstName = person.FirstName,
                                   LastName = person.LastName
                               };

                foreach (var person in newQuery)
                {
                    host.Out.WriteLine("{0} {1}", person.FirstName, person.LastName);
                }


                // COUNT
                host.Out.WriteLine("COUNT");
                var countQuery = from person in personStore.Items<Person>()
                                 where person.LastName.EndsWith("sson")
                                 select person;

                host.Out.WriteLine("Number of persons in store: {0}", countQuery.Count());



                // REFERENCES
                host.Out.WriteLine("REFERENCES");
                var referenceQuery = from person in personStore.Items<Person>()
                                     where person.Address.Country == "Sweden"
                                     select new
                                     {
                                         FirstName = person.FirstName,
                                         LastName = person.LastName,
                                         ZipCode = person.Address.ZipCode
                                     };


                foreach (var person in referenceQuery)
                {
                    host.Out.WriteLine("{0} {1} {2}", person.FirstName, person.LastName, person.ZipCode);
                }

                // COLLECTIONS
                host.Out.WriteLine("COLLECTIONS");

                // Compare the collection in the database to see if it contains the element on the stack.
                // this only works with collections of "inline" types
                var compareItem = personStore.Items<Person>().First();
                var queryStoreCollectionAgainsStackItem = from person in personStore.Items<Person>()
                         where person.OtherNames.Contains(compareItem.FirstName.Reverse()) select person;

                foreach (var person in queryStoreCollectionAgainsStackItem)
                {
                    host.Out.WriteLine("{0} {1}", person.FirstName, person.LastName);
                }

                // Compare the collection on the stack to see if there any items in the database that match
                // this only works with collections of "inline" types
                var compareItems = personStore.Items<Person>().First().OtherNames.Select(item => item.Reverse());

                var queryStackCollectionAgainsStoreItem = from person in personStore.Items<Person>()
                                                          where compareItems.Contains(person.FirstName)
                                                          select person;

                foreach (var person in queryStackCollectionAgainsStoreItem)
                {
                    host.Out.WriteLine("{0} {1}", person.FirstName, person.LastName);
                }

                // GROUPING
                var groupQuery = from person in personStore.Items<Person>()
                                 group person by person.LastName into g
                                 select new { Name = g.Key, Count = g.Count() };

                foreach (var person in groupQuery)
                {
                    host.Out.WriteLine("{0} {1}", person.Name, person.Count);
                }

                // You can also call Items() to returns items as their native saved types (see LoadSaveType class)
                // and ItemsAsPropertyBag() to return items as PropertyBag(s)

                host.WaitForUser();
            }
            finally
            {
                GlobalTypeToStoreMap.Instance.Remove(typeof(Address));
                GlobalTypeToStoreMap.Instance.Remove(typeof(Company));
            }
        }
    }
}
