﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples
{
    class ImplicitDynamicMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Create a bag of properties to save
            PropertyBag pb = new PropertyBag();
            pb.Add("FirstName", "Jack");
            pb.Add("LastName", "Williams");
            pb.Add("Gender", "m");

            // infer the type mappings for the store by generating them from the current property bag
            // this works fine if you know that all property bags saved to this store will have this 'shape'
            // if you allow optional properties then you should use explicit mapping instead
            // see the ExplicitDynamicMapping sample class
            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", pb.GenerateTypeBag());

            foreach (PropertyBag bag in store.ItemsAsPropertyBag())
            {
                host.Out.WriteLine(bag["FirstName"]);
                host.Out.WriteLine(bag["LastName"]);
                host.Out.WriteLine(bag["DateOfBirth"]);
                host.Out.WriteLine(bag["Gender"]);
            }

            host.WaitForUser();
        }
    }
}
