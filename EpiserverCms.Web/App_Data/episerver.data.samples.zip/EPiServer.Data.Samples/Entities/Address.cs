﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace EPiServer.Data.Samples.Entities
{
    public class Address
    {
        public Guid Id
        {
            get;
            set;
        }

        public string Line1
        {
            get;
            set;
        }

        public string Line2
        {
            get;
            set;
        }

        public string City
        {
            get;
            set;
        }

        public string Country
        {
            get;
            set;
        }

        public string ZipCode
        {
            get;
            set;
        }

        public override string ToString()
        {
            return String.Format(CultureInfo.CurrentCulture, "{0}, {1}, {2}, {3}", Line1, ZipCode, City, Country);
        }
    }
}
