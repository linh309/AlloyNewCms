﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPiServer.Data.Samples.Entities
{
    class Data
    {
        public static List<Person> CreateData()
        {
            Person p = new Person();
            var names = GetNames();
            var strings = GetStrings();
            var adressData = GetAdressData();

            Random r = new Random();
            List<Person> people = new List<Person>();
            for (int i = 0; i < names.Count; i++)
            {
                p = new Person();
                p.FirstName = names[i][0];
                p.LastName = names[i][1];
                
                p.OtherNames = new string[]
                {
                    (names[i][0]).Reverse(),
                    (names[i][1]).Reverse(),
                };
                
                p.DateOfBirth = new DateTime(r.Next(1950, 1985), r.Next(1, 12), r.Next(1, 28));
                p.DateOfDeath = i<50?(DateTime?)(new DateTime(r.Next(1985, 2008), r.Next(1, 12), r.Next(1, 28))):null;

                p.Address = new Address()
                {
                    Line1 = adressData[i][0],
                    Line2 = adressData[i][1],
                    City = adressData[i][2],
                    Country = adressData[i][3],
                    ZipCode = adressData[i][4]
                };
                p.Friends = new Person[]
                {
                    new Person()
                    {
                        FirstName = names[r.Next(0,names.Count - 1)][0],
                        LastName = names[r.Next(0,names.Count - 1)][1],
                        DateOfBirth = new DateTime(r.Next(1950,1985), r.Next(1,12), r.Next(1,28))
                    },
                    new Person()
                    {
                        FirstName = names[r.Next(0,names.Count - 1)][0],
                        LastName = names[r.Next(0,names.Count - 1)][1],
                        DateOfBirth= new DateTime(r.Next(1950,1985), r.Next(1,12), r.Next(1,28))
                    }
                };

                people.Add(p);
            }
            return people;
        }

        private static List<string> GetStrings()
        {
            List<string> strings = new List<string>();
            strings.Add("couple of weeks ago there was a Ruby conference in San Francisco called GoGaRuCo (Golden Gate Ruby Conference).");
            strings.Add("This conference has grabbed attention due to a talk at which the presenter illustrated a discussion of CouchDB by using");
            strings.Add("sexually suggestive pictures of women. Unsurprisingly the result has been a fair bit of heated, and occasionally offensive, debate.");
            strings.Add("The main lines of the debate are familiar. Various people, not all women, lay the charge that the images and general tone was offensive.");
            strings.Add("Such material makes women feel degraded and alienated. This kind of presentation would not be tolerated at most professional events.");
            strings.Add("Defenders of the presenter point out that the slides were humorous and no offense was intended.");
            strings.Add("The Rails community has always had a edginess to it - in part because much of the Rails community is focused on the");
            strings.Add("rejection of enterprise values - both technologically and socially. David Heinemeier Hansson is happy to proclaim");
            strings.Add("himself as an R rated individual and is happy to consign \"professional\" to the same pit to which he cast \"enterprise\".");
            strings.Add("I'll admit to finding much to like in the general edginess of the Rails world. Innovation often involves seeing a");
            return strings;
        }

        private static List<string[]> GetNames()
        {
            List<string[]> names = new List<string[]>();
            names.Add(new string[] { "Jacob", "xMiassonx" }); // to test trim
            names.Add(new string[] { "Michael", "Chloesson" });
            names.Add(new string[] { "Ethan", "Nataliesson" });
            names.Add(new string[] { "Joshua", "Sarahsson" });
            names.Add(new string[] { "Daniel", "Alexissson" });
            names.Add(new string[] { "Christopher", "Gracesson" });
            names.Add(new string[] { "Anthony", "Ellasson" });
            names.Add(new string[] { "William", "Briannasson" });
            names.Add(new string[] { "Matthew", "Haileysson" });
            names.Add(new string[] { "Andrew", "Taylorsson" });
            names.Add(new string[] { "Alexander", "Annasson" });
            names.Add(new string[] { "David", "Kaylasson" });
            names.Add(new string[] { "Joseph", "Lilysson" });
            names.Add(new string[] { "Noah", "Laurensson" });
            names.Add(new string[] { "James", "Victoriasson" });
            names.Add(new string[] { "Ryan", "Savannahsson" });
            names.Add(new string[] { "Logan", "Nevaehsson" });
            names.Add(new string[] { "Jayden", "Jasminesson" });
            names.Add(new string[] { "John", "Lilliansson" });
            names.Add(new string[] { "Nicholas", "Juliasson" });
            names.Add(new string[] { "Tyler", "Sofiasson" });
            names.Add(new string[] { "Christian", "Kayleesson" });
            names.Add(new string[] { "Jonathan", "Michaelsson" });
            names.Add(new string[] { "Nathan", "Ethansson" });
            names.Add(new string[] { "Samuel", "Joshuasson" });
            names.Add(new string[] { "Benjamin", "Danielsson" });
            names.Add(new string[] { "Aiden", "Christophersson" });
            names.Add(new string[] { "Gabriel", "Anthonysson" });
            names.Add(new string[] { "Dylan", "Williamsson" });
            names.Add(new string[] { "Elijah", "Matthewsson" });
            names.Add(new string[] { "Brandon", "Andrewsson" });
            names.Add(new string[] { "Gavin", "Alexandersson" });
            names.Add(new string[] { "Jackson", "Davidsson" });
            names.Add(new string[] { "Jose", "Noahsson" });
            names.Add(new string[] { "Caleb", "Jamessson" });
            names.Add(new string[] { "Mason", "Ryansson" });
            names.Add(new string[] { "Jack", "Logansson" });
            names.Add(new string[] { "Kevin", "Jaydensson" });
            names.Add(new string[] { "Evan", "Johnsson" });
            names.Add(new string[] { "Isaac", "Nicholassson" });
            names.Add(new string[] { "Zachary", "Tylersson" });
            names.Add(new string[] { "Isaiah", "Christiansson" });
            names.Add(new string[] { "Justin", "Jonathansson" });
            names.Add(new string[] { "Jordan", "Nathansson" });
            names.Add(new string[] { "Luke", "Samuelsson" });
            names.Add(new string[] { "Robert", "Benjaminsson" });
            names.Add(new string[] { "Austin", "Aidensson" });
            names.Add(new string[] { "Landon", "Gabrielsson" });
            names.Add(new string[] { "Cameron", "Dylansson" });
            names.Add(new string[] { "Jocelyn", "Elijahsson" });
            names.Add(new string[] { "Emily", "Brandonsson" });
            names.Add(new string[] { "Isabella", "Austinsson" });
            names.Add(new string[] { "Emma", "Landonsson" });
            names.Add(new string[] { "Ava", "Cameronsson" });
            names.Add(new string[] { "Madison", "Jocelynsson" });
            names.Add(new string[] { "Sophia", "Emilysson" });
            names.Add(new string[] { "Olivia", "Isabellasson" });
            names.Add(new string[] { "Abigail", "Emmasson" });
            names.Add(new string[] { "Hannah", "Avasson" });
            names.Add(new string[] { "Elizabeth", "Madisonsson" });
            names.Add(new string[] { "Addison", "Sophiasson" });
            names.Add(new string[] { "Samantha", "Oliviasson" });
            names.Add(new string[] { "Ashley", "Abigailsson" });
            names.Add(new string[] { "Alyssa", "Hannahsson" });
            names.Add(new string[] { "Mia", "Elizabethsson" });
            names.Add(new string[] { "Chloe", "Addisonsson" });
            names.Add(new string[] { "Natalie", "Samanthasson" });
            names.Add(new string[] { "Sarah", "Ashleysson" });
            names.Add(new string[] { "Alexis", "Alyssasson" });
            names.Add(new string[] { "Grace", "Sydneysson" });
            names.Add(new string[] { "Ella", "Gabriellasson" });
            names.Add(new string[] { "Brianna", "Katherinesson" });
            names.Add(new string[] { "Hailey", "Alexasson" });
            names.Add(new string[] { "Taylor", "Destinysson" });
            names.Add(new string[] { "Anna", "Jessicasson" });
            names.Add(new string[] { "Kayla", "Morgansson" });
            names.Add(new string[] { "Lily", "Kaitlynsson" });
            names.Add(new string[] { "Lauren", "Brookesson" });
            names.Add(new string[] { "Victoria", "Allisonsson" });
            names.Add(new string[] { "Savannah", "Makaylasson" });
            names.Add(new string[] { "Nevaeh", "Averysson" });
            names.Add(new string[] { "Jasmine", "Alexandrasson" });
            names.Add(new string[] { "Lillian", "Jacobsson" });
            names.Add(new string[] { "Julia", "Gavinsson" });
            names.Add(new string[] { "Sofia", "Jacksonsson" });
            names.Add(new string[] { "Kaylee", "Angelsson" });
            names.Add(new string[] { "Sydney", "Josesson" });
            names.Add(new string[] { "Gabriella", "Calebsson" });
            names.Add(new string[] { "Katherine", "Masonsson" });
            names.Add(new string[] { "Alexa", "Jacksson" });
            names.Add(new string[] { "Destiny", "Kevinsson" });
            names.Add(new string[] { "Jessica", "Evansson" });
            names.Add(new string[] { "Morgan", "Isaacsson" });
            names.Add(new string[] { "Kaitlyn", "Zacharysson" });
            names.Add(new string[] { "Brooke", "Isaiahsson" });
            names.Add(new string[] { "Allison", "Justinsson" });
            names.Add(new string[] { "Makayla", "Jordansson" });
            names.Add(new string[] { "Avery", "Lukesson" });
            names.Add(new string[] { "Alexandra", "Robertsson" });
            names.Add(new string[] { "Allison", "Evansson" });
            names.Add(new string[] { "Andy", "Xyz" });
            return names;
        }

        private static List<string[]> GetAdressData()
        {
            List<string[]> ad = new List<string[]>();
            ad.Add(new string[] { "Ankargränd 1", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Baggensgatan 2", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Bankkajen 3", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Bedoirsgränd 4", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Benickebrinken 5", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "BirgerJarlsgatan 6", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Bollhusgränd 7", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Bredgränd 8", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Brunnsgränd 9", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "DidrikFicksGränd 10", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "DrakensGränd 11", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Drottninggatan,Stockholm 12", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "FerkensGränd 13", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "FinskaKyrkogränd 14", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Folkungagatan,Stockholm 15", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "FruGunillasGränd 16", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "FunckensGränd 17", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Gaffelgränd 18", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "ListofstreetsandsquaresinGamlastan 19", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Gåsgränd 20", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "GöranHälsingesGränd 21", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Götgatan 22", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Hamngatan 23", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "HelgaLekamensGränd 24", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Högvaktsterrassen 25", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Ignatiigränd 26", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Johannesgränd 27", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Järntorgsgatan 28", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Kanslikajen 29", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Kindstugatan 30", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Klockgjutargränd 31", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Kolmätargränd 32", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Kråkgränd 33", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Kungsgatan,Stockholm 34", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Källargränd 35", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Kåkbrinken 36", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Kcont. 37", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Köpmanbrinken 38", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Köpmangatan 39", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Lejonbacken 40", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "LejonstedtsGränd 41", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "LillaHoparegränd 42", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "LillaNygatan 43", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Malmskillnadsgatan 44", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Munkbrogatan 45", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Munkbrohamnen 46", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Munkbroleden 47", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Myntgatan 48", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "MårtenTrotzigsGränd 49", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "NorrMälarstrand 50", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "NorraBankogränd 51", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "NorraDryckesgränd 52", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Nybrogatan 53", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Nygränd 54", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Österlånggatan 55", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Packhusgränd 56", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "PederFredagsGränd 57", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Pelikansgränd 58", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Prästgatan 59", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Rehnsgatan,Stockholm 60", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Riddargatan 61", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Riddarhusgränd 62", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Riddarhuskajen 63", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Riksgatan 64", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Rådhusgränd 65", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Salviigränd 66", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "SchönfeldtsGränd 67", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Själagårdsgatan 68", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "SkepparKarlsGränd 69", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "SkepparOlofsGränd 70", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Skeppsbrokajen 71", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Skeppsbron 72", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Skomakargatan 73", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Skottgränd 74", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Skräddargränd 75", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Slottsbacken 76", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Slottskajen 77", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Slussplan 78", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Solgränd 79", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "SpektensGränd 80", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "StaffanSassesGränd 81", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Stenbastugränd 82", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "StoraGråmunkegränd 83", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "StoraHoparegränd 84", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "StoraNygatan 85", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Storkyrkobrinken 86", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Strandvägen 87", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Strömsborgsbron 88", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Sturegatan 89", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Svartmangatan 90", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Sveavägen 91", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "SvenVintapparesGränd 92", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "SödraBankogränd 93", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "SödraDryckesgränd 94", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Telegrafgränd 95", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Torgdragargränd 96", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "Triewaldsgränd 97", "somewhere", "Stockholm", "Sweden", "12345" });
            ad.Add(new string[] { "Trädgårdsgatan 98", "somewhere", "Göteborg", "Sweden", "12345" });
            ad.Add(new string[] { "Trädgårdstvärgränd 99", "somewhere", "Upssala", "Sweden", "12345" });
            ad.Add(new string[] { "Trångsund 100", "somewhere", "Örebro", "Sweden", "12345" });
            ad.Add(new string[] { "SkepparOlöfsGränd 70", "somewhere", "Hoby", "Sweden", "12345" });
            return ad;
        }
    }
}
