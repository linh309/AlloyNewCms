﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples.Entities
{
    class PersonWithIDynamicData : IDynamicData
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public char Gender { get; set; }

        #region IDynamicData Members

        public Identity Id
        {
            get;
            set;
        }

        #endregion
    }
}
