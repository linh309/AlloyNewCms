﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPiServer.Data.Samples.Entities
{
    class Company
    {
        public string Name { get; set; }
        public Address Address { get; set; }
        public Person ChiefExecutive { get; set; }
        public IEnumerable<Person> Employees { get; set; }
    }
}
