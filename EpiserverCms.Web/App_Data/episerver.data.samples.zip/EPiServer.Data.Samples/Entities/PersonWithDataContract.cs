﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace EPiServer.Data.Samples.Entities
{
    [DataContract]
    class PersonWithDataContract
    {
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public DateTime DateOfBirth { get; set; }

        // Don't map this!!
        public char Gender { get; set; }
    }
}
