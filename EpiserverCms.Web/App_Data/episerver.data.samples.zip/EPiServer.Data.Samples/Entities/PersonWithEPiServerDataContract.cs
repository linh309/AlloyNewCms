﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples.Entities
{
    /// <summary>
    /// Class with different serialization patterns for DataContract consumers (e.g. Windows Communication Found (WCF))
    /// and Dynamic Data Store
    /// </summary>
    [DataContract]
    [EPiServerDataContract]
    class PersonWithEPiServerDataContract
    {
        /// <summary>
        /// Serialize this with Windows Communication Found (WCF)
        /// and to Dynamic Data Store
        /// </summary>
        [DataMember]
        [EPiServerDataMember]
        public string FirstName { get; set; }

        /// <summary>
        /// Serialize this with Windows Communication Found (WCF)
        /// and to Dynamic Data Store
        /// </summary>
        [DataMember]
        [EPiServerDataMember]
        public string LastName { get; set; }

        /// <summary>
        /// Serialize this with Windows Communication Found (WCF)
        /// but NOT to Dynamic Data Store
        /// </summary>
        [DataMember]
        public DateTime DateOfBirth { get; set; }

        /// <summary>
        /// Don't map this!!
        /// </summary>
        public char Gender { get; set; }
    }
}
