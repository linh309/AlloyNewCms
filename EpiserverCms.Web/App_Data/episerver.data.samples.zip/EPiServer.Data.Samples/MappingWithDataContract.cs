﻿using System;
using System.Runtime.Serialization;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class MappingWithDataContract : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Save a new person
            PersonWithDataContract p = new PersonWithDataContract()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25),
                Gender = 'm'
            };

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(PersonWithDataContract));
            Identity id = store.Save(p);

            // Now load the person back
            PersonWithDataContract loadedPerson = store.Load<PersonWithDataContract>(id);

            // Ensure we got out person back
            host.Assert(loadedPerson != null);

            host.Out.WriteLine(loadedPerson.FirstName);
            host.Out.WriteLine(loadedPerson.LastName);
            host.Out.WriteLine(loadedPerson.DateOfBirth);

            // Gender should be the default value as it was not mapped and therefore not saved
            host.Out.WriteLine(loadedPerson.Gender);

            host.WaitForUser();
        }
    }
}
