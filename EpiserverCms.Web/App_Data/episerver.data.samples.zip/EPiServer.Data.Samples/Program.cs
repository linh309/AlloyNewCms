﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Samples.Host;
using System.Diagnostics;
using EPiServer.Data.Dynamic;
using System.Data.Common;
using EPiServer.Data.Dynamic.Providers;

namespace EPiServer.Data.Samples
{
    public class Program
    {
        static void Main(string[] args)
        {
            RunSamples(new ConsoleHostApplication());
        }

        public static void RunSamples(IHostApplication host)
        {
            // Use the default factory for the samples
            DynamicDataStoreFactory.Instance = new EPiServerDynamicDataStoreFactory();
 
            // Uncomment the sample you want to run
            new UsingStores().RunWithReset(host);
            new LoadSaveType().RunWithReset(host);
            new LoadSaveProperyBag().RunWithReset(host);
            new UsingImplicitIdentity().RunWithReset(host);
            new UsingManagedIdentity().RunWithReset(host);
            new ExplicitDynamicMapping().RunWithReset(host);
            new ImplicitDynamicMapping().RunWithReset(host);
            new MappingWithDataContract().RunWithReset(host);
            new MappingWithEPiServerDataContract().RunWithReset(host);
            new MappingWithTypeHandler().RunWithReset(host);
            new UsingGlobalTypeToStoreMapping().RunWithReset(host);
            new UsingLocalTypeToStoreMapping().RunWithReset(host);
            new UsingGlobalStoreToTableMapping().RunWithReset(host);
            new UsingIndexes().RunWithReset(host);
            new UsingFind().RunWithReset(host);
            new UsingLinq().RunWithReset(host);
            new StoreReMapping().RunWithReset(host);

            DynamicDataStoreFactory.Instance = null;
        }        
    }

    internal class ConsoleHostApplication : IHostApplication
    {
        #region IHostApplication Members

        public System.IO.TextWriter Out
        {
            get
            {
                return Console.Out;
            }
        }

        public void WaitForUser()
        {
            Console.WriteLine("Press any key to continue");
            Console.ReadKey();
        }

        public void Assert(bool condition)
        {
            Debug.Assert(condition);
        }

        public void Assert(bool condition, string message)
        {
            Debug.Assert(condition, message);
        }

        #endregion
    }
}
