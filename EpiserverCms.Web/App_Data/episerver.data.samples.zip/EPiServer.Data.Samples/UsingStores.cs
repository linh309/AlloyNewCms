﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{ 
    class UsingStores : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // In the following examples we use Guid's (converted to strings) as store names.
            // This guarantees that the stores with not exist and therefore ensures the sample
            // code shows the concepts it is supposed to

            string storeName = Guid.NewGuid().ToString();

            {
                // Get a store that doesn't exist yet
                DynamicDataStore store = DynamicDataStoreFactory.Instance.GetStore(storeName);

                // null should have been returned
                host.Assert(store == null);
            }

            {
                // Get a store that doesn't exist yet using the implicit type name
                DynamicDataStore store = DynamicDataStoreFactory.Instance.GetStore(typeof(Person));

                // null should have been returned
                host.Assert(store == null);
            }

            {
                // Create a store with a specific name
                DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore(storeName, typeof(Person));

                host.Assert(store != null);
                host.Assert(store.Name == storeName);

                // Note the store definition was inferred from the Type

            }

            {
                // Create a store with an implicit (type) name
                DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore(typeof(Person));

                host.Assert(store != null);

                // StoreName should be the types full name
                host.Assert(store.Name == typeof(Person).FullName);
            }

            {
                // Create an store with an explicit set a type mappings
                // need to use a new store name as we've already created one with the old name with different mappings
                storeName = Guid.NewGuid().ToString(); 
                Dictionary<string, Type> typeBag = new Dictionary<string, Type>();
                typeBag.Add("FirstName", typeof(string));

                DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore(storeName, typeBag);

                host.Assert(store != null);
                host.Assert(store.Name == storeName);
            }

            {
                // delete a store with an implicit name
                DynamicDataStoreFactory.Instance.DeleteStore(typeof(Person), true);
                host.Assert(DynamicDataStoreFactory.Instance.GetStore(typeof(Person)) == null);
            }

            {
                // delete a store with a specific name
                DynamicDataStoreFactory.Instance.DeleteStore(storeName, false);
                host.Assert(DynamicDataStoreFactory.Instance.GetStore(storeName) == null);
            }

            host.WaitForUser();
        }
    }
}
