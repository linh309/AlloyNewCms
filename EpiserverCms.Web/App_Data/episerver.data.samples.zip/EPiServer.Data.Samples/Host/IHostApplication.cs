﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EPiServer.Data.Samples.Host
{
    public interface IHostApplication
    {
        System.IO.TextWriter Out { get; }
        void WaitForUser();
        void Assert(bool condition);
        void Assert(bool condition, string message);
    }
}
