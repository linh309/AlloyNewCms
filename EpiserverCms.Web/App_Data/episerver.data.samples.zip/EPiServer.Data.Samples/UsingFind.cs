﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;
using System.Globalization;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class UsingFind : SampleBase
    {
        EPiServer.Data.Samples.Host.IHostApplication _host;

        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            _host = host;

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person));

            List<Person> people = Person.CreateChildren();
            foreach (Person person in people)
            {
                store.Save(person);
            }

            Find(store);
            LoadAll(store);

            _host.WaitForUser();
        }

        private void Find(DynamicDataStore store)
        {
            // Find with one parameter
            List<Person> mia = store.Find<Person>("FirstName", "Mia").ToList();
            PrintToScreen("Find with one parameter", mia);

            // Find with more parameters
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add("FirstName", "Mia");
            parameters.Add("LastName", "Elizabethsson");
            List<Person> miaIII = store.Find<Person>(parameters).ToList();
            PrintToScreen("Find with more parameters", miaIII);

            // You can also call Find() to returns items as their native saved types (see LoadSaveType class)
            // and FindAsPropertyBag() to return items as PropertyBag(s)
        }

        private void LoadAll(DynamicDataStore store)
        {
            List<Person> everyone = store.LoadAll<Person>().ToList();
            PrintToScreen("LoadAll", everyone);
        }

        #region Print to screen
        void PrintToScreen(string caption, List<Person> persons)
        {
            PrintStart(caption);

            foreach (Person person in persons)
            {
                PrintPerson(person);
            }

            PrintEnd();
        }

        void PrintToScreen(string caption, Person person)
        {
            PrintStart(caption);
            PrintPerson(person);
            PrintEnd();
        }

        void PrintStart(string caption)
        {
            _host.Out.WriteLine("**************");
            _host.Out.WriteLine(caption);
            _host.Out.WriteLine("**************");
        }

        void PrintPerson(Person person)
        {
            _host.Out.WriteLine(person.ToString());
        }

        void PrintEnd()
        {
            _host.Out.WriteLine("**************");
            _host.Out.WriteLine("");
        }
        #endregion
    }
}
