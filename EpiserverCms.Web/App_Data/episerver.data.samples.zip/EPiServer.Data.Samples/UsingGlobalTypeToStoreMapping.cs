﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Samples.Entities;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples
{
    /// <summary>
    /// This sample demonstrates how you can steer which stores
    /// types are saved in at a global level
    /// </summary>
    class UsingGlobalTypeToStoreMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {            
            // Create a person with an address
            Person p = new Person()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25),
                Address = new Address()
                {
                     Line1 = "AnyStreet",
                     City = "AnyCity"
                },
                Friends = new List<Person>()
                {
                    new Person()
                    {
                        FirstName = "Andy",
                        LastName = "Collins"
                    }
                },
                Associates = new List<Person>()
                {
                    new Person()
                    {
                        FirstName = "Mary",
                        LastName = "Forde"
                    }
                }
            };

            try
            {
                // Ensure all Person sub-objects are saved to the "People" store
                GlobalTypeToStoreMap.Instance.Add(typeof(Person), "People");

                // Ensure all Address sub-objects are saved to the "Addresses" store
                GlobalTypeToStoreMap.Instance.Add(typeof(Address), "Addresses");

                // NOTE: This and store mapping can also be done by adding the EPiServerDataStoreAttribute to the class being saved
                // e.g.
                // [EPiServerDataStore(StoreName="MyStore")]
                // class MyClass.....
                //

                // Create a store.
                // Note that if the store name was not given then the top level Person
                // object would be saved in a store called EPiServer.Data.Samples.Entities.Person
                // instead (FullName of the Type of the object)
                DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person));
                store.Save(p);

                // All 3 people objects should have been saved in the "People" store
                foreach (Person person in store.Items<Person>())
                {
                    host.Out.WriteLine(person);
                }

                // The Address object should have been saved in the "Addresses" store
                foreach (Address address in DynamicDataStoreFactory.Instance.GetStore("Addresses").Items<Address>())
                {
                    host.Out.WriteLine(address);
                }

                host.WaitForUser();
            }
            finally
            {
                // As these are global it's quite important
                // they are removed so they don't affect
                // the rest of the samples.
                // In a regular app you would probably just add them
                // at startup and leave them there for the lifetime of the app
                GlobalTypeToStoreMap.Instance.Remove(typeof(Person));
                GlobalTypeToStoreMap.Instance.Remove(typeof(Address));
            }
        }
    }
}
