﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    /// <summary>
    /// This sample demonstrates how you can steer which stores
    /// types are saved in at a local level
    /// </summary>
    class UsingLocalTypeToStoreMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Create a company with a CEO and some employees
            Company company = new Company()
            {
                Address = new Address()
                {
                    Line1 = "45 West 22nd Street",
                    City = "New Cargo"
                },
                ChiefExecutive = new Person()
                {
                    FirstName = "Larry",
                    LastName = "Kiroch"
                },
                Employees = new List<Person>()
                 {
                     new Person()
                     {
                         FirstName = "Fred",
                         LastName = "Elderino"
                     },
                     new Person()
                     {
                         FirstName = "Janet",
                         LastName = "Wuvven"
                     }
                 }
            };

            // I don't want all Person objects to go the a "People" store
            // so I can't use the GlobalTypeToStoreMap.
            // I want the CEO to go to the "Executives" store
            // and the employees to go to the "Employees" store.
            // This is achieved the passing a delegate to the
            // DynamicDataStore.Save method and instructing
            // which store each object should be saved in

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("Companies", typeof(Company));
            store.Save(company, new TypeToStoreMapper(MapStore));

            // instead of passing a delegate method you could also use
            // an inline delegate or a lamba expression.
            // The advantage if this is that you have access to the
            // object you're saving
            // e.g.
            store.Save(company, (propertyName, propertyValue) =>
            {
                if (propertyValue == company.ChiefExecutive)
                {
                    return "Executives";
                }

                if (propertyValue is Person && company.Employees.Contains((Person)propertyValue))
                {
                    return "Employees";
                }

                return null;
            });            

            // Now check the Executives and Employees stores
            foreach (Person executive in DynamicDataStoreFactory.Instance.GetStore("Executives").Items<Person>())
            {
                host.Out.WriteLine(executive);
            }

            foreach (Person employee in DynamicDataStoreFactory.Instance.GetStore("Employees").Items<Person>())
            {
                host.Out.WriteLine(employee);
            }

            host.WaitForUser();
        }

        private string MapStore(string propertyName, object propertyValue)
        {
            if (propertyName == "ChiefExecutive")
            {
                return "Executives";
            }

            if (propertyName == "Employees")
            {
                return "Employees";
            }

            return null;
        }


    }
}
