﻿using System;
using EPiServer.Data;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    class LoadSaveType : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Save a new person
            Person p = new Person()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25)
            };

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person));
            Identity id = store.Save(p);

            // Now load the person back
            Person loadedPerson = store.Load<Person>(id);

            // Ensure we got out person back
            host.Assert(loadedPerson != null);

            host.Out.WriteLine(loadedPerson.FirstName);
            host.Out.WriteLine(loadedPerson.LastName);
            host.Out.WriteLine(loadedPerson.DateOfBirth);

            // You can also load the data back into a PropertyBag
            PropertyBag pb = store.LoadAsPropertyBag(id);
            host.Out.WriteLine(pb["FirstName"]);
            host.Out.WriteLine(pb["LastName"]);
            host.Out.WriteLine(pb["DateOfBirth"]);

            // or into a completely different type
            // only properties with matching names will be assigned to the object
            MyPerson myPerson = store.Load<MyPerson>(id);
            host.Out.WriteLine(myPerson.FirstName);
            host.Out.WriteLine(myPerson.LastName);

            // or load it as the type is was saved as (which is Person)
            object obj = store.Load(id);
            host.Assert(obj is Person);

            host.WaitForUser();
        }
    }

    class MyPerson
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
