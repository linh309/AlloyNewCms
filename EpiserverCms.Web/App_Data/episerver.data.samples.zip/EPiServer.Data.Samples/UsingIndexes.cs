﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Samples.Entities;

namespace EPiServer.Data.Samples
{
    /// <summary>
    /// This class demonstrates how properties saved in the DDS can be indexed
    /// </summary>
    class UsingIndexes : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Create a person 
            Person p = new Person()
            {
                FirstName = "Jack",
                LastName = "Williams",
                DateOfBirth = new DateTime(1973, 05, 25)
            };

            // Create a store with the LastName property indexed
            StoreDefinitionParameters parameters = new StoreDefinitionParameters();
            parameters.IndexNames.Add("LastName");

            // NOTE: this can also be done by adding the EPiServerDataIndexAttribute on the classes' property
            // e.g.
            // [EPiServerDataIndex]
            // public string LastName {get;set;}
            //

            // Create the store and save the person
            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person), parameters);
            store.Save(p);

            // See that the LastName property was mapped to IndexedStringXX and not StringXX
            InlinePropertyMap mapping = store.StoreDefinition.GetMapping("LastName") as InlinePropertyMap;
            host.Assert(mapping.ColumnInfo.Name.ToLower().StartsWith("indexed"));

            host.WaitForUser();
        }
    }
}
