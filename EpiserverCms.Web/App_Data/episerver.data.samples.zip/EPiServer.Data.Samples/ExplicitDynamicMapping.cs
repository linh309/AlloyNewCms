﻿using System;
using System.Collections.Generic;
using EPiServer.Data;
using EPiServer.Data.Dynamic;

namespace EPiServer.Data.Samples
{
    class ExplicitDynamicMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // Map up our 'People' store
            Dictionary<String, Type> storeMappings = new Dictionary<string,Type>();
            storeMappings.Add("FirstName", typeof(String));
            storeMappings.Add("LastName", typeof(String));
            storeMappings.Add("DateOfBirth", typeof(DateTime));
            storeMappings.Add("Gender", typeof(Char));

            DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", storeMappings);
            
            // Now we can save PropertyBags without having to have values for all the properties
            PropertyBag pb = new PropertyBag();
            pb.Add("FirstName", "Jack");
            pb.Add("LastName", "Williams");
            pb.Add("Gender", "m");
            
            // Don't know his date of birth yet
            // If we hadn't mapped the store explicity first then only the FirstName, LastName and Gender
            // would be mapped            
            store.Save(pb);            

            PropertyBag pb2 = new PropertyBag();
            pb2.Add("FirstName", "Anne");
            pb2.Add("LastName", "Jackson");
            pb2.Add("Gender", "f");
            pb2.Add("DateOfBirth", new DateTime(1953, 01, 16));
            store.Save(pb2);

            foreach (PropertyBag bag in store.ItemsAsPropertyBag())
            {
                host.Out.WriteLine(bag["FirstName"]);
                host.Out.WriteLine(bag["LastName"]);
                host.Out.WriteLine(bag["DateOfBirth"]);
                host.Out.WriteLine(bag["Gender"]);
            }

            host.WaitForUser();
        }       
    }
}
