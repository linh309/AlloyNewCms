﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EPiServer.Data.Dynamic;
using EPiServer.Data.Dynamic.Providers;
using System.Data.Common;
using EPiServer.Data.Samples.Entities;
using System.Data;

namespace EPiServer.Data.Samples
{
    /// <summary>
    /// This sample demonstrates how you can map stores to your own 'big table'
    /// </summary>
    class UsingGlobalStoreToTableMapping : SampleBase
    {
        public override void Run(EPiServer.Data.Samples.Host.IHostApplication host)
        {
            // The big table needs to be created before it can mapped
            // This would typically be done by a applications installation program
            DataStoreProvider provider = DataStoreProvider.CreateInstance();

            if (!(provider is DbDataStoreProvider))
            {
                throw new NotSupportedException("The sample required a database provider");
            }

            using (IDbCommand cmd = ((DbDataStoreProvider)provider).CreateCommand())
            {
                if (provider is OracleDataStoreProvider)
                {
                    cmd.CommandText = CustomBigTable.OracleCreateTable;
                }
                else
                {
                    cmd.CommandText = CustomBigTable.SqlCreateTable;
                }

                cmd.ExecuteNonQuery();
            }

            try
            {
                // Map the Person Type to the people store
                GlobalTypeToStoreMap.Instance.Add(typeof(Person), "People");

                // Map a store to our custom big table using the API
                // NOTE: This and store mapping can also be done by adding the EPiServerDataTableAttribute
                // and EPiServerDataStoreAttribute to the class being saved
                // e.g.
                // [EPiServerDataTable(TableName="MyCustomTable")]
                // [EPiServerDataStore(StoreName="MyStore")]
                // class MyClass.....
                //

                StoreDefinitionParameters parameters = new StoreDefinitionParameters();
                parameters.TableName = CustomBigTable.TableStorageName;
                GlobalStoreDefinitionParametersMap.Instance.Add("People", parameters);

                // Create a person with an friends and associates
                Person p = new Person()
                {
                    FirstName = "Jack",
                    LastName = "Williams",
                    DateOfBirth = new DateTime(1973, 05, 25),
                    Friends = new List<Person>()
                {
                    new Person()
                    {
                        FirstName = "Andy",
                        LastName = "Collins"
                    }
                },
                    Associates = new List<Person>()
                    {
                        new Person()
                        {
                            FirstName = "Mary",
                            LastName = "Forde"
                        }
                    }
                };

                // By default the FirstName property will be mapped to the String01 column (properties are sorted alphabetically)
                // You can map any property on your type to a specific column in any big table using either the API as shown in the code
                // or by adding the EPiServerDataColumnAttribute to your property
                // e.g.
                // [EPiServerDataColumn(ColumnName="MyForeignKeyColumn")]
                // public int MyForeignKey { get;set;}

                parameters.ColumnNamesMap.Add("FirstName", "String02");

                // Create a store.
                // Note that if the store name was not given then the top level Person
                // object would be saved in a store called EPiServer.Data.Samples.Entities.Person
                // instead (FullName of the Type of the object)
                DynamicDataStore store = DynamicDataStoreFactory.Instance.CreateStore("People", typeof(Person));
                store.Save(p);

                // All 3 people objects should have been saved in the "People" store
                foreach (Person person in store.Items<Person>())
                {
                    host.Out.WriteLine(person);
                }

                // ensure the data is actually being read from the custom big table and not the default big table
                using (IDbCommand cmd = ((DbDataStoreProvider)provider).CreateCommand())
                {
                    cmd.CommandText = string.Format("select * from {0} where StoreName = 'People'", CustomBigTable.TableStorageName);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);

                            foreach (object value in values)
                            {
                                if (DBNull.Value != value)
                                {
                                    host.Out.WriteLine(value);
                                }
                            }
                        }
                    }
                }

                host.WaitForUser();
            }
            finally
            {
                // ensure the global mappings are deleted as they will affect
                // the other samples
                GlobalTypeToStoreMap.Instance.Remove(typeof(Person));
                GlobalStoreDefinitionParametersMap.Instance.Remove("People");

                ((DbDataStoreProvider)provider).ExecuteTransaction(() =>
                {
                    // ensure the big table is deleted
                    using (IDbCommand cmd = ((DbDataStoreProvider)provider).CreateCommand())
                    {
                        cmd.CommandText = "delete from tblBigTableReference";
                        cmd.ExecuteNonQuery();

                        if (provider is OracleDataStoreProvider)
                        {
                            cmd.CommandText = CustomBigTable.OracleDeleteTable;
                        }
                        else
                        {
                            cmd.CommandText = CustomBigTable.SqlDeleteTable;
                        }

                        cmd.ExecuteNonQuery();

                        cmd.CommandText = "delete from tblBigTableIdentity";
                        cmd.ExecuteNonQuery();
                    }
                });
            }
        }
    }

    class CustomBigTable
    {
        public static string TableStorageName = "tblCustomBigTable";
        public static string OracleCreateTable = " BEGIN EXECUTE IMMEDIATE 'CREATE TABLE " + TableStorageName +
                                        " (PKID         NUMBER(38) not null, " +
                                        " ROWNUMBER    NUMBER(11) default (1) not null,  " +
                                        " STORENAME    NVARCHAR2(128) not null,  " +
                                        " ITEMTYPE     NVARCHAR2(512) not null,  " +
                                        " BOOLEAN01    NUMBER(1),  " +
                                        " INTEGER01    NUMBER(11), " +
                                        " INTEGER02    NUMBER(11),  " +
                                        " LONG01       NUMBER(38),  " +
                                        " DATETIME01   TIMESTAMP(3), " +
                                        " GUID01       RAW(16),  " +
                                        " FLOAT01      BINARY_DOUBLE,  " +
                                        " STRING01     NCLOB,  " +
                                        " STRING02     NCLOB,  " +
                                        " STRING03     NCLOB,  " +
                                        " BINARY01     BLOB)';" +
                                        " EXECUTE IMMEDIATE 'alter table " + TableStorageName +
                                        " add constraint PK_" + TableStorageName + " primary key (PKID,ROWNUMBER)';  " +
                                        " EXECUTE IMMEDIATE 'alter table " + TableStorageName +
                                        " add constraint FK_" + TableStorageName + "IDENT foreign key (PKID)  " +
                                        " references TBLBIGTABLEIDENTITY (PKID)';  " +
                                        " EXECUTE IMMEDIATE 'alter table " + TableStorageName +
                                        " add constraint CH_" + TableStorageName +
                                        " check (ROWNUMBER>=1)';END;";

        public static string SqlCreateTable = "create table [dbo].[" + TableStorageName + "] " +
                                        " ([pkId] bigint not null, " +
                                        " [Row] int not null default(1) constraint CH_" + TableStorageName + " check ([Row]>=1), " +
                                        " [StoreName] nvarchar(128) not null, " +
                                        " [ItemType] nvarchar(512) not null, " +
                                        " [Boolean01] bit null, " +
                                        " [Integer01] int null, " +
                                        " [Integer02] int null, " +
                                        " [Long01] bigint null, " +
                                        " [DateTime01] datetime null, " +
                                        " [Guid01] uniqueidentifier null, " +
                                        " [Float01] float null, " +
                                        " [String01] nvarchar(max) null, " +
                                        " [String02] nvarchar(max) null, " +
                                        " [String03] nvarchar(max) null, " +
                                        " [Binary01] varbinary(max) null, " +
                                        " constraint [PK_" + TableStorageName + "] primary key clustered([pkId],[Row]), " +
                                        " constraint [FK_" + TableStorageName + "_tblBigTableIdentity] foreign key ([pkId]) " +
                                        " references [tblBigTableIdentity]([pkId]))";

        public static string SqlDeleteTable = "DROP TABLE " + TableStorageName;
        public static string OracleDeleteTable = "BEGIN EXECUTE IMMEDIATE 'DROP TABLE " + TableStorageName + "';END;";
    }
}
