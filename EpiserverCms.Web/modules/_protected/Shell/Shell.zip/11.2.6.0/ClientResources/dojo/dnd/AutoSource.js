//>>built
define("dojo/dnd/AutoSource",["../_base/declare","./Source"],function(_1,_2){return _1("dojo.dnd.AutoSource",_2,{constructor:function(){this.autoSync=true;}});});